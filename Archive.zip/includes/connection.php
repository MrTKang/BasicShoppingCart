<?php

$server="localhost";
$user="root";
$password="root";
$db="mystore";

$mysqli = new mysqli($server, $user, $password, $db);

?>