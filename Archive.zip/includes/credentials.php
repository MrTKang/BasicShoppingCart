<?php

$GMAIL_ACCOUNT = "freestore0202@gmail.com";
$GMAIL_PASSWORD = "MyFreeStore";

$PAYPAL_AUTH_TOKEN = "W9b9px8Yu7geqreMniZAx8a0HAdoQF1uS3ygc06oHfNEjat7-GGVW1JOc2y";
?>