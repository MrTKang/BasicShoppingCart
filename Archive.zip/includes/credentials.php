<?php

$GMAIL_ACCOUNT = "freestore0202@gmail.com";
$GMAIL_PASSWORD = "MyFreeStore";

?>