INSERT INTO products (name, description, price, image) VALUES (
'Mac Book Pro',
'',
1175.0,
'images/macpro.jpg'
);
